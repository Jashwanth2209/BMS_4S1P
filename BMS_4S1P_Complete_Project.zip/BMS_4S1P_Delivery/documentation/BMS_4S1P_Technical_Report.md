# BMS 4S1P MATLAB Project Documentation

Calculations formulas and step by step procedure

Prepared 5 November 2026

## 1 Project purpose and delivered model

This project models four Panasonic NCR18650BD lithium ion cells in a 4S1P pack with a 20 ohm load. It includes pack measurements, coulomb counting, a pack protection flag, four passive balancing branches, a capacity ratio SOH calculation, and signal logging. The supplied BMS_4S1P.slx is a copy of the model saved on 4 November 2026. The original model and generated component source files are preserved together.

Use this report to understand the calculations, reproduce the model, run the supplied files, and identify what still needs validation. A fault flag is implemented, but a fault controlled series disconnect and individual cell voltage protection are not present. The SOH input is a fixed capacity; its 100 percent output is an arithmetic demonstration, not measured battery aging.

The older 31 October guide recorded a less complete model and an approximately 0.800 to 0.755 SOC trace over 600 s. That observation is historical. The current model starts its estimator at 0.825 and its four physical cells at [0.90; 0.80; 0.50; 0.80]. Historical results and analytical examples below are labeled separately from the delivered configuration.

## 2 System architecture and current implementation

The physical circuit connects BatteryPack_4S1P to a 20 ohm load with a series Current Sensor and a parallel Voltage Sensor. Simscape Electrical Reference and Solver Configuration blocks complete the physical network. PS Simulink Converters expose pack voltage and discharge positive current to ordinary Simulink logic.

Pack current passes through Gain -1 to SOC_Estimator. Pack voltage and current feed three comparators in Protection. CellPositiveBus and CellNegativeBus connect the generated battery to CellBalancing, where two Array Connection blocks expose matching positive and negative nodes. Four sensors measure cell voltages. The controller drives four switch and resistor shunts and logs the switch commands and branch currents.

| Function | Present in saved model | Interpretation |
|---|---|---|
| BatteryPack_4S1P | Detailed 4S1P module with external buses | Four physical cell states |
| SOC_Estimator | 3.03 Ah, 1 s, Gain -1, initial 0.825 | Single pack current estimate |
| Protection | Voltage >16.8 V, voltage <10 V, current >8 A | Fault flag only |
| CellBalancing | Four 82 ohm branches and controlled switches | Passive voltage balancing |
| SOH_and_Logging | Capacity division, gain 100, 0 to 100 saturation | Fixed 3.03 Ah input gives 100 percent |
| Persistent logs | Pack V, pack I, SOC, fault, commands, shunt currents, SOH | To Workspace timeseries |
| Series fault cutoff | Not present | Future extension |
| Individual cell protection | Not present | Future extension |

The balancing switches are across individual cells. They are not the missing series load disconnect. Physical presence of a block is distinct from validation of its behavior; see the supplied validation record and Section 8.

## 3 Software and exact saved parameters

The model targets MATLAB R2026a Update 5, Simulink, Simscape, Simscape Battery, and Simscape Electrical. Preserve the full generated library folder. The directly referenced battery library is BMS_4S1P_ExternalBalancing_lib_lib.slx, and its component source package is +BMS_4S1P_ExternalBalancing_lib. The other saved generated libraries and MAT files are retained as design source snapshots.

| Parameter | Value | Meaning |
|---|---|---|
| Series and parallel count | 4 and 1 | 4S1P |
| Selected cell | Panasonic NCR18650BD | Builder parameterization |
| Cell and pack capacity | 3.03 Ah | Series does not increase Ah |
| Nominal cell and pack voltage | 3.6 V and 14.4 V | Nominal calculation values |
| Pack protection thresholds | >16.8 V, <10 V, >8 A | Strict comparisons |
| Physical initial SOC targets | 0.90, 0.80, 0.50, 0.80 | High priority socCell vector |
| Estimator initial SOC | 0.825 | Separate scalar initial value |
| Estimator sample time | 1 s | Discrete coulomb counter |
| Load and stop time | 20 ohm and 600 s | Saved configuration |
| Balancing resistors | Four times 82 ohm | One per cell |
| Balancing threshold and hysteresis | 0.020 V and 0.005 V | Controller mask values |
| Balancing on and off delay | 1 s and 1 s | Controller mask values |
| Balancing sample time | 1 s | Controller mask value |
| Electrical switch threshold | 0.5 | Command 1 closes switch |
| Voltage Unit Delay | Initial 4.08; sample time inherited | Initialization is not a measured cell voltage |
| Available and nominal capacity for SOH | 3.03 Ah and 3.03 Ah | Both fixed constants |
| Solver selection | VariableStepAuto | Independent of controller sample time |

The mean physical initial SOC is 0.75 and the minimum is 0.50. The estimator initial SOC of 0.825 is neither of these. Consequently the scalar SOC trace cannot be presented as an accurate initialized estimate of all four cells. The single current input also omits the unequal charge removed by the shunts. Preserve the saved setup for reproduction; make any revised initialization an explicitly named experiment.

The voltage endpoints and 8 A threshold are project settings, not a complete cell operating envelope. The generated battery terminal operating range parameter is [2.25, Inf] V; this numerical model range is distinct from the project's 2.5 and 4.2 V protection basis. The selected capacity is 3.03 Ah. The recorded cell geometry is radius 0.009125 m, height 0.0651 m, mass 0.0495 kg; four bare cells weigh 0.198 kg in that representation.

## 4 Formulas and worked calculations

### 4.1 Series and parallel relationships

For identical cells with equal state and ideal interconnects, series connection adds voltage and parallel connection adds ampere hour capacity.

Equation 1: Vpack nominal = Ns * Vcell nominal

Equation 2: Qpack = Np * Qcell

Equation 3: Epack nominal = Vpack nominal * Qpack

Here voltage is in V, capacity in Ah, and energy in Wh. For this pack:

Vpack nominal = 4 * 3.6 = 14.4 V

Qpack = 1 * 3.03 = 3.03 Ah

Epack nominal = 14.4 * 3.03 = 43.632 Wh, approximately 43.63 Wh

The Builder value of 10.91 Wh per cell gives 4 * 10.91 = 43.64 Wh. The small difference is rounding. Nominal energy is an estimate; simulated delivered energy requires integrating terminal power over the actual discharge.

Equation 4: Eout Wh = integral of [Vpack(t) * Idis(t)] dt / 3600

The integration time is in seconds. Idis is positive for discharge. The corresponding SI energy is Eout J = integral of [Vpack(t) * Idis(t)] dt, with 1 Wh = 3600 J. The nominal 43.632 Wh is 157075.2 J. Under mismatch or aging, usable series pack capacity is limited by the first cell to reach its permitted endpoint.

Upper pack endpoint = 4 * 4.2 = 16.8 V

Lower pack endpoint = 4 * 2.5 = 10.0 V

These sums do not guarantee that every cell remains within its own limits. For example, cell voltages of 4.30, 4.10, 4.10, and 4.10 V sum to 16.60 V, below the pack overvoltage threshold even though the first cell exceeds 4.2 V.

### 4.2 Load current power and discharge rate

Equation 5: Iload = Vpack / RL

Equation 6: Pload = Vpack * Iload = Vpack^2 / RL = Iload^2 * RL

Voltage is in V, resistance in ohms, current in A, and power in W. Using the measured terminal voltage automatically accounts for the voltage presented to the load. Calculations at nominal or full charge voltage are illustrative operating points.

| Operating point | Pack voltage | Current through 20 ohm | Load power |
|---|---|---|---|
| Nominal voltage | 14.40 V | 0.7200 A | 10.368 W |
| Upper voltage endpoint | 16.80 V | 0.8400 A | 14.112 W |
| Previously displayed voltage | 16.31 V | 0.8155 A | 13.3008 W |

A constant resistance produces changing current as voltage changes. It is not a constant current or constant power load. The physical model determines the time dependent voltage; the calculations above do not replace the battery block.

Equation 7: Discharge C rate = Idis / Qn

Numerically, current in A divided by capacity in Ah gives a rate in inverse hours, conventionally written as a C rate. At nominal voltage, 0.72 / 3.03 = 0.238 C. At 16.8 V, 0.84 / 3.03 = 0.277 C. The 8 A comparator corresponds to 8 / 3.03 = 2.640 C for one parallel cell. This conversion describes the chosen setting; it does not validate a cell operating limit.

### 4.3 Coulomb counting state of charge

Let z be SOC as a fraction from 0 to 1, Idis be discharge positive current in A, Qn be nominal capacity in Ah, and time t be in seconds. The ideal discharge equation is:

Equation 8: z(t) = z0 - integral of Idis(t) dt / (3600 * Qn)

For a discrete estimate with sample time Ts:

Equation 9: z[k+1] = z[k] - Idis[k] * Ts / (3600 * Qn)

The factor 3600 converts Ah to ampere seconds. Here 3.03 Ah = 10908 A s = 10908 C of electric charge. The letter C used as a charge unit means coulomb, while C rate in Section 4.2 denotes a discharge rate.

For a constant illustrative current of 0.8 A during 600 s:

Removed charge = 0.8 * 600 / 3600 = 0.133333 Ah

SOC decrease = 0.133333 / 3.03 = 0.0440044

Final SOC = 0.800 - 0.0440044 = 0.755996, or 75.60 percent

The decrease is 4.400 percentage points. If the current were held at the 16.31 V load estimate of 0.8155 A, the calculated final SOC would be 0.755143. The recorded approximate 0.800 to 0.755 trend implies an average current of:

Equation 10: Iaverage = (zstart - zend) * 3600 * Qn / T

Iaverage = (0.800 - 0.755) * 3600 * 3.03 / 600 = 0.8181 A

These estimates agree in order and scale with the recorded trace. They are not an exact comparison against logged simulation samples because the trace endpoints were recorded approximately.

The model current sensor is positive during discharge. The configured SOC Estimator block expects the opposite sign for discharge, so the recorded path applies Gain = -1 before the block. Use this sign correction once. Adding another negative sign would make estimated SOC rise during discharge.

Set the estimator initial SOC deliberately and inspect the battery plant initial condition separately. The InitialSOC input initializes the estimator; it does not by itself initialize the physical cell states. A trustworthy comparison requires consistent plant and estimator initial states.

Equation 9 assumes ideal coulombic efficiency. A more general charge and discharge estimator may use a justified efficiency factor and available capacity rather than nominal capacity. Clamp a displayed estimate to the intended range only after preserving diagnostic information; saturation cannot correct sensor bias, wrong initial SOC, or model error.

With the saved passive balancing circuit, each cell has a different net discharge current. For cell i, an ideal relationship is Icell,i = Ipack + Ibleed,i during discharge. A single pack current counter cannot resolve the extra charge removed by individual shunts. Per cell SOC estimation must account for balancing currents or use the battery model states as a clearly labeled reference.

### 4.4 Approximate available runtime

Equation 11: runtime hours = (zstart - zstop) * Qavailable / Iaverage

For a deliberately simplified calculation with zstart = 0.8, zstop = 0, Qavailable = 3.03 Ah, and constant 0.8 A, runtime is 3.03 h. At constant 0.72 A it is 3.367 h. These are charge accounting examples, not demonstrated runtimes. A resistor load changes current, the voltage cutoff can occur before the assumed SOC endpoint, and capacity varies with conditions. The model must be simulated to the selected cell limits to obtain a usable runtime prediction.

### 4.5 Protection logic

The recorded implementation uses three strict comparisons:

Equation 12: FOV = (Vpack > 16.8)

Equation 13: FUV = (Vpack < 10.0)

Equation 14: FOC = (Ipack > 8.0)

Equation 15: FaultFlag = FOV OR FUV OR FOC

Vpack is in V and Ipack is in A. With strict comparisons, equality to a threshold alone does not assert that fault. The current comparison detects positive discharge overcurrent only. Charging protection needs a separate negative current threshold or a deliberately chosen absolute current rule with appropriate directional limits.

The planned cell checks are FcellOV = any cell voltage > Vcell max and FcellUV = any cell voltage < Vcell min. Combine them with the pack faults and drive a physical series switch. A first demonstration can use SwitchCommand = NOT FaultFlag. A practical simulation of protection should also define measurement filtering, trip persistence, reset hysteresis, and a latch or reset rule. Without these, disconnecting the load may remove the triggering condition and repeatedly reconnect it. A Unit Delay can break a direct algebraic control loop, but adds one sample of detection or actuation latency.

### 4.6 Passive balancing current power and time

For an ideal closed shunt switch and resistor Rb across cell i:

Equation 16: Ibleed,i = Vi / Rb

Equation 17: Pbleed,i = Vi^2 / Rb

At 4.2 V with Rb = 82 ohm:

Ibleed = 4.2 / 82 = 0.0512195 A, or 51.22 mA

Pbleed = 4.2^2 / 82 = 0.215122 W

For a 3 percentage point SOC mismatch in otherwise identical 3.03 Ah cells:

Equation 18: Excess charge Ah = Delta z * Qn

Excess charge = 0.03 * 3.03 = 0.0909 Ah

Equation 19: Approximate bleed time hours = Excess charge Ah / Ibleed

Bleed time = 0.0909 / 0.0512195 = 1.7747 h, or approximately 106.5 minutes

At that constant current, 600 s removes only 0.0085366 Ah, equivalent to 0.2817 percentage points of SOC. A short 600 s plot may therefore show switching and shunt current without showing a large reduction in SOC mismatch. Actual time depends on cell voltage, switch duty cycle, switch resistance, load, cell parameters, and the stopping rule. The calculated dissipation is a simulation value; component sizing requires thermal margin and ratings.

The saved controller compares each cell voltage with the minimum cell voltage. Define Delta Vi = Vi - min(V1, V2, V3, V4). One explicit custom hysteresis convention is to turn a shunt on above 0.020 V and turn it off below 0.015 V, retaining its previous state between these values. This illustrates a 0.005 V hysteresis width. When using the MathWorks block, verify its documented parameter definitions and apply equivalent settings rather than assuming the same interpretation from a field name alone.

Voltage balancing is not identical to equalizing SOC. Terminal voltage depends on SOC, load, temperature, and resistance. The demonstration should state its operating conditions and measure the reduction in cell voltage spread at comparable conditions.

### 4.7 Capacity based state of health

Equation 20: SOH capacity percent = 100 * Qavailable / Qnominal

Both capacities must use the same units and a comparable measurement procedure. For an explicitly assumed available capacity of 2.424 Ah:

SOH = 100 * 2.424 / 3.03 = 80 percent

This example checks arithmetic only. No 80 percent aging state was measured or demonstrated in the recorded model. A full controlled discharge can estimate capacity from integral of discharge current divided by 3600, provided the starting and ending conditions are defined. For a partial SOC window with independently known SOC change, Qavailable = discharged Ah / Delta z. Estimating that SOC change with the same assumed capacity can make this calculation circular. Document the independent information or calibrated aging model used.

## 5 Step by step model construction

### 5.1 Prepare the environment

1. Start MATLAB R2026a and confirm that the required Simulink and Simscape products are installed and licensed. Use the ver command to inspect installed products.
2. Use a dedicated project folder containing the top level model, generated battery library, generated component files, and associated MAT data. Preserve the original files before making changes.
3. Open Battery Builder from Apps, Simscape, Battery Builder, or enter batteryBuilder in the Command Window.

### 5.2 Create the selected cell and module

1. Duplicate the example cell and rename the working cell BMS_Cell.
2. Set its cell model to batt_lib/Cells/Battery (Table-Based). Preserve the space before the opening parenthesis.
3. Choose Panasonic NCR18650BD in the available part parameterization. Apply the data and verify the configured 3.03 Ah capacity.
4. Create Parallel Assembly BMS_1P, choose BMS_Cell, and set NumParallelCells to 1.
5. Create Module BMS_4S1P_Module, choose BMS_1P, and set NumSeriesAssemblies to 4. Select Detailed resolution and NoVariation for the recorded baseline.
6. For the external balancing revision, duplicate the module and set BalancingStrategy to External. The recorded generated block was named BMS_4S1P_Module_1.
7. Generate a library into the project folder and retain all generated files. Changing the Builder object does not automatically replace a previously placed module instance. Use the intended newly generated block in the model.

The table based battery block uses empirical parameter tables from the selected parameterization. This report does not infer a new open circuit voltage curve, resistance table, thermal model, or aging law. Inspect the generated block mask and data before reporting those internal parameters.

### 5.3 Build the battery subsystem and load

1. Create BatteryPack_4S1P and remove the default ordinary Simulink pass through ports and wire.
2. Place the generated module. Add physical Connection Port blocks for Batt + and Batt - and connect them to the module main terminals.
3. In the external balancing version, expose +Bus as CellPositiveBus and -Bus as CellNegativeBus. The recorded battery subsystem numbered these physical ports 3 and 4.
4. At top level, connect the pack into a closed circuit with a 20 ohm resistor and Current Sensor in series. Orient the sensor so discharge is positive.
5. Add a Voltage Sensor across the pack, with its positive terminal toward Batt +. Add Electrical Reference and Solver Configuration blocks.
6. Connect sensor physical signal outputs to PS Simulink Converters. Set voltage output units to V and current output units to A. Connect Scopes or Displays and branch signals to the BMS logic.
7. Update the model diagram and resolve connection or unit errors. Run a short simulation to check current and voltage polarity before proceeding.

Do not connect the cell node buses to a Scope or ordinary Simulink Inport. They are arrays of physical electrical nodes. Also do not connect the positive cell bus directly to the main positive terminal or the negative cell bus directly to the main negative terminal; each bus contains distinct cell nodes.

### 5.4 Implement the SOC estimator

1. In SOC_Estimator, connect measured pack current to a Gain block set to -1.
2. Connect the gain output to SOC Estimator (Coulomb Counting). Set capacity to 3.03 Ah and sample time to 1 s.
3. Connect Constant 0.825 to InitialSOC to reproduce the current saved model. The historical demonstration used 0.8. Keep the single pack current input configuration.
4. Connect SOC to an Outport and Scope. Inspect the battery plant initial targets separately and align them for a controlled experiment.
5. Set stop time to 600 s, simulate, and check that SOC decreases during discharge. Compare its charge change against Equation 8 using the actual measured current.

### 5.5 Implement the pack protection flag

1. Create Protection with PackVoltage_V at input 1 and PackCurrent_A at input 2.
2. Add Compare To Constant blocks for voltage > 16.8, voltage < 10, and current > 8.
3. Connect their Boolean outputs to a three input Logical Operator set to OR.
4. Export FaultFlag and connect a Display. Branch voltage and current signals so the existing measurement and SOC paths remain connected.
5. Run the normal 20 ohm case and expect FaultFlag = 0. In a test copy, lower the overvoltage threshold to 14.5 V, below the current run voltage, and expect FaultFlag = 1. Restore 16.8 V and repeat the normal run.

This test proves the comparison and display path. It does not prove that the battery is physically disconnected.

## 6 Balancing SOH logging and further extensions

### 6.1 Reproduce the existing cell voltage measurement paths

1. Open CellBalancing and add two physical Connection Ports for the positive and negative cell node arrays. Keep ordinary control ports separate from the physical ports and give each a clear name.
2. At top level, connect BatteryPack_4S1P CellPositiveBus and CellNegativeBus to the corresponding balancing ports.
3. Add two Array Connection blocks from Simscape Utilities. Set Electrical Domain, Scalar Elements, and four scalar elements. Connect one to each array bus.
4. Place four Voltage Sensors across matching positive and negative element pairs, maintaining the same cell order on both arrays.
5. Convert outputs to V and combine them into a four element Simulink vector. Plot all four and verify that their sum matches pack voltage within the model topology and numerical tolerance.
6. Establish a 1 s controller sample time and use a suitable delay or filter if the switching feedback produces an algebraic loop. Record the resulting control latency.

The R2026a procedure uses Array Connection. The older Array of Electrical Nodes Connector is not the block used for this recorded release.

### 6.2 Reproduce and validate the passive balancing circuit

1. Add Passive Cell Balancing from the Simscape Battery BMS library. Feed the four measured cell voltages and a BalanceEnable signal.
2. Set the saved 0.020 V difference threshold, 0.005 V hysteresis, 1 s on delay, 1 s off delay, and 1 s controller sample time. Check the block documentation for hysteresis semantics.
3. Split the four command outputs with a Demux. Send each through a Simulink PS Converter with unit 1 to its own electrical Switch control port. Use a switch threshold of 0.5 so command 1 closes it.
4. For each cell, connect a shunt branch from its positive node through Current Sensor, Switch, and 82 ohm resistor back to the matching negative node. This branch is in parallel with that cell.
5. Convert the four branch currents to A and log them along with the command vector. Export BalancingActive as an explicitly defined logical indication, such as any command being on.
6. Reproduce the saved physical socCell targets [0.90;0.80;0.50;0.80] with Specify enabled and High priority. A smaller mismatch such as [0.80;0.79;0.78;0.77] can be used in a separately named experiment. The estimator InitialSOC does not change these physical targets.
7. Simulate with balancing disabled to establish a comparison, then enable balancing under the same conditions. Allow enough time for the small shunt current to remove meaningful charge.
8. Compare cell voltage spread, individual currents, commands, and cell states. Verify the highest voltage cells bleed and the intended mismatch decreases under comparable measurement conditions.

### 6.3 Future extension for disconnect and cell protection

1. Insert a controlled electrical Switch in series with the load path. Convert NOT FaultFlag to a physical control signal with unit 1.
2. Add per cell overvoltage and undervoltage comparisons and OR them into the fault decision.
3. Define fault persistence, reset hysteresis, latch behavior, and permitted reset conditions. Use a deliberate sampled or state based controller if direct feedback creates numerical problems or repeated reconnects.
4. Exercise overvoltage, undervoltage, and overcurrent separately in simulation. Verify the flag and the resulting near zero load current after the intended trip delay. Restore nominal thresholds after testing.

### 6.4 Reproduce SOH and saved results

1. In SOH_and_Logging, divide AvailableCapacity_Ah by Constant 3.03, multiply by 100, and apply Saturation with lower 0 and upper 100.
2. Connect the top level Constant 3.03 to AvailableCapacity_Ah. This reproduces a constant 100 percent SOH. Use a separate test copy with 2.424 Ah to demonstrate 80 percent.
3. Preserve the To Workspace blocks and Timeseries format. Current variable names are PackVoltage_log, PackCurrent_log, SOC_log, FaultFlag_log, SOH_log, SwitchCommand_log, and BalancingCurrent1_log through BalancingCurrent4_log.
4. Individual cell voltage logging is not configured as a To Workspace output in this snapshot. Add a named log to the voltage vector in a test copy when validating cell voltage spread. Keep its cell order consistent with the array element order.
5. To turn the SOH arithmetic into estimation, replace the fixed available capacity input with an independently justified capacity measurement or calibrated aging model. A constant ratio does not model degradation.

## 7 Opening running and preserving the project

1. Extract the complete project package before opening MATLAB files. Keep the generated battery folders and data in their supplied relative locations.
2. Set Current Folder to the supplied matlab folder and run Open_BMS_4S1P. For a manual run, set MATLAB Current Folder to the model folder and add the folder containing the generated libraries and component packages to the path for the session.
3. Open BMS_4S1P.slx. Update the diagram to reveal missing references before simulation. If a generated component library is unresolved, restore the matching generated files rather than replacing it with an unrelated battery block.
4. Check the load resistance, SOC capacity and sample time, estimator initial SOC, plant initial conditions, and restored fault thresholds. Inspect the saved solver configuration; the 1 s estimator sample time does not imply that the whole Simscape network must use a 1 s solver step.
5. Set stop time to the intended scenario, starting with 600 s for the historical discharge demonstration. Run and view the voltage, current, SOC, and FaultFlag displays or logged signals.
6. Save an editable copy for subsequent work. Keep the original model and generated library available so a failed change can be compared with the saved baseline.

BMS_4S1P_Calculations reproduces the engineering arithmetic in Section 4. Running arithmetic is independent of verifying the Simscape model; a calculation script is not a replacement for the SLX model and its dependencies. Run results = BMS_4S1P_Calculations for arithmetic outputs in results/calculations. Run simOut = Run_BMS_4S1P(600) for the model and timestamped MAT and CSV outputs. Run Open_BMS_4S1P to view the model without simulation. See README.md for the complete file map.

## 8 Verified simulation and validation plan

The delivered copy completed a 600 s simulation in MATLAB R2026a Update 5 on 5 November 2026. The run used the saved physical SOC vector, estimator value, load, controller, and protection parameters without saving changes to the SLX. Full data are supplied in results/BMS_4S1P_simulation.mat and the individual CSV files.

| Logged quantity | Start | End at 600 s |
|---|---|---|
| Pack voltage | 15.265024 V | 15.103232 V |
| Pack discharge current | 0.76325122 A | 0.75516161 A |
| Estimated scalar SOC | 0.82500000 | 0.78324887 |
| Fault flag | 0 | 0 |
| SOH ratio | 100 percent | 100 percent |
| Command vector | [0 0 0 0] | [1 1 0 1] |
| Cell 1 shunt current | About 0 A | 47.6611 mA |
| Cell 2 shunt current | About 0 A | 46.5057 mA |
| Cell 3 shunt current | About 0 A | About 0 A |
| Cell 4 shunt current | About 0 A | 46.5057 mA |

![Actual simulation plots](BMS_4S1P_results.png)

Figure 1. Actual 600 s outputs from the delivered model. The identical cell 2 and cell 4 current traces overlap. The inactive cell 3 branch carries only about 36 nA of switch leakage. These results demonstrate simulation and branch actuation, not full balance convergence, calibrated SOC accuracy, or physical fault cutoff.

BMS_4S1P_Calculations also executed successfully in MATLAB. Assertions checked unchanged series Ah capacity, analytical versus discrete coulomb counting, all three fault conditions and equality boundaries, and the 80 percent capacity ratio example. Fault arithmetic tests are separate from fault injection into the Simscape model.

### 8.1 Further acceptance tests

| Test | Stimulus | Expected evidence | Recorded status |
|---|---|---|---|
| Normal discharge | 20 ohm load and nominal thresholds | Positive discharge current, falling SOC, FaultFlag 0 | Passed 600 s in delivered copy |
| Coulomb accounting | Integrate logged current over 600 s | SOC change agrees with charge divided by 3.03 Ah within declared numerical tolerance | Approximate trace check only |
| Overvoltage flag | Temporary threshold 16.0 V below measured voltage | Flag changes 0 to 1 and returns to 0 after restoration | Observed in prior build |
| Undervoltage flag | Temporary threshold above measured voltage | Undervoltage component and flag assert | Not recorded as tested |
| Overcurrent flag | Temporary threshold below measured positive current | Overcurrent component and flag assert | Not recorded as tested |
| Threshold equality | Feed signals exactly at comparison limits in a logic test | Strict comparisons remain false at equality | Passed in calculation function |
| Load cutoff | Assert each fault after switch implementation | Load current falls near zero after defined delay | Remaining |
| Cell limit protection | One cell exceeds a limit while pack sum can remain acceptable | Individual cell check trips | Remaining |
| Passive balancing | Saved unequal initial states and enabled shunts | Correct commands and currents; quantify voltage spread | Implemented; quantitative convergence requires comparison runs |
| SOH arithmetic | Known capacity inputs 3.03 and 2.424 Ah | 100 and 80 percent respectively | Fixed ratio implemented; aging not estimated |

Compare actual logged samples rather than reading precise values from a screenshot. Define tolerances according to solver settings, sensor models, and signal sampling. Record actual outcomes and retain failures; do not mark planned features as validated because their formulas are correct.

## 9 Troubleshooting

| Symptom | Likely cause | Check or correction |
|---|---|---|
| Negative pack voltage | Voltage Sensor polarity reversed | Connect sensor positive toward Batt + |
| SOC rises during discharge | Current sign wrong or corrected twice | Confirm positive sensor discharge and one Gain -1 |
| SOC starts at unexpected value | Estimator and plant initial states differ | Check both InitialSOC and physical cell targets |
| Missing generated block | Library or generated package not on path | Restore matching dependencies and add their parent folder |
| Array bus cannot connect to Scope | Electrical nodes treated as ordinary signals | Use Array Connection and Voltage Sensors with converters |
| Little visible balancing in 600 s | Shunt current small relative to cell capacity | Use calculated balancing timescale and extend scenario |
| Fault asserted but current flows | Flag has no physical actuator | Implement and verify a series switch |
| Repeated cutoff and reconnect | No latch or reset hysteresis | Define stateful trip and reset behavior |
| Algebraic loop or solver difficulty | Direct switching feedback or network setup | Inspect network and add deliberate sampled control where appropriate |
| No SOH decay | Aging disabled or capacity input unchanged | Use a justified aging model or measured available capacity |

## 10 Model equations and interpretation

The supplied generated component uses a table based cell model. Its source exposes SOC_vecCell, V0_vecCell, R0_vecCell, and AHCell. The SOC grid runs from 0 to 1 in increments of 0.01. The lookup data are preserved in the generated SSC files and in the model mask; they should not be replaced by a linear voltage versus SOC assumption.

For the default resistance and open circuit voltage representation, a useful discharge positive interpretation is:

Equation 21: Vcell,i = V0(zi) - Icell,i * R0(zi)

Equation 22: Vpack = sum of Vcell,i for i = 1 to 4

Equation 23: d zi / dt = -(Ipack + Ibleed,i) / (3600 * Qcell)

These equations explain the table lookup voltage, resistance drop, and charge balance. The complete executed implementation remains the MathWorks Battery Table Based block and generated source, including its configured interpolation, numerical initialization, and switch behavior.

| Cell SOC | Table open circuit voltage | Table resistance |
|---|---|---|
| 0.50 | 3.63116 V | 0.04797 ohm |
| 0.80 | 3.88686 V | 0.04372 ohm |
| 0.90 | 3.99856 V | 0.04594 ohm |
| 1.00 | 4.10453 V | 0.03326 ohm |

The 4.10453 V table value at SOC 1 is not the same as the 4.2 V design endpoint used in the pack threshold arithmetic. The report retains both with their meanings rather than altering the supplied data.

For the saved initial SOC vector, the sum of tabulated open circuit voltages is 15.40344 V and the sum of resistances is 0.18135 ohm. Ignoring shunts during startup, an ideal series resistance approximation gives I = 15.40344 / (20 + 0.18135), approximately 0.76325 A, and terminal voltage approximately 15.265 V. This is a consistency estimate, not a replacement for the recorded simulation outputs.

The initial 40 percentage point physical SOC spread is deliberately large. Even at a constant ideal 51.22 mA, bleeding 0.40 times 3.03 Ah would take about 23.66 hours. A 600 s simulation is useful for checking commands and current paths; it cannot establish full SOC equalization. Loading, changing voltage, and controller duty cycle further affect convergence.

The useful next work is to validate convergence with comparable runs, align the meaning of the scalar SOC estimate, and add a fault controlled series disconnect and cell limits. Available capacity needs an independent source before SOH can describe actual aging.

## 11 References

The delivered SLX and generated SSC sources provide the current settings. The project build guide and resume notes dated 31 October 2026 provide the historical observations. The external links below are the technical references retained with that guide. They should be checked against the installed MATLAB release and selected cell parameterization when extending the model.

1. Project record. BMS_4S1P_Project_Guide.md and BMS_4S1P_Resume_Notes.md, 31 October 2026.
2. MathWorks Battery Builder. https://www.mathworks.com/help/simscape-battery/ref/batterybuilder-app.html
3. MathWorks Module object. https://www.mathworks.com/help/simscape-battery/ref/simscape.battery.builder.module.html
4. MathWorks Module generated block. https://www.mathworks.com/help/simscape-battery/ref/modulegeneratedblock.html
5. MathWorks SOC Estimator Coulomb Counting. https://www.mathworks.com/help/simscape-battery/ref/socestimatorcoulombcounting.html
6. MathWorks Passive Cell Balancing. https://www.mathworks.com/help/simscape-battery/ref/passivecellbalancing.html
7. MathWorks Array Connection. https://www.mathworks.com/help/simscape/ref/arrayconnection.html
8. MathWorks Switch. https://www.mathworks.com/help/simscape/ref/switch.html
9. Panasonic NCR18650BD product flyer, as linked in the project record. https://mediac.industry.panasonic.eu/p/2020-09/NCR18650BD-Improved_Lithium-ion_Flyer_2020-09-07.pdf

The project record also identifies BMS abstract new.pdf and an IJERT paper titled Simulation of Battery Management System Using MATLAB Simulink as background source material. They are not used here as proof of implemented features or measured performance.
