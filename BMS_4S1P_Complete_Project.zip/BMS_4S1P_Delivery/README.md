# BMS 4S1P project package

Prepared 5 November 2026. Includes the actual saved model, its generated dependencies, a technical report, MATLAB calculations, and a successful 600 s simulation result.

## Start here

1. Extract the complete ZIP to a writable folder.
2. Read `documentation/BMS_4S1P_Technical_Report.pdf` for calculations, formulas, configuration, construction steps, results, and limitations. The matching Markdown is editable documentation.
3. Start MATLAB R2026a with Simulink, Simscape, Simscape Battery, and Simscape Electrical.
4. Set MATLAB Current Folder to the package's `matlab` folder.
5. Run `Open_BMS_4S1P` to open the actual model. If another copy with the same name is open, save and close it first.
6. Run `simOut = Run_BMS_4S1P(600)` to simulate and export MAT and CSV logs into a timestamped folder under `results`.
7. Run `calculations = BMS_4S1P_Calculations` for the worked numerical examples. This file requires only base MATLAB and writes to `results/calculations`.

## Files

- `matlab/original_model/BMS_4S1P.slx`: byte-for-byte copy of the saved 4 November model.
- `matlab/original_model/BMS_4S1P_ExternalBalancing_lib_lib.slx` and `+BMS_4S1P_ExternalBalancing_lib`: directly referenced generated battery library and source package. Keep the `+` in folder names.
- Other generated SLX, MAT, and `+` folders: the saved design source snapshots, retained for rebuilding and inspection. MAT files contain battery design objects; they are not simulation traces.
- `matlab/Open_BMS_4S1P.m`: session path setup and model opener.
- `matlab/Run_BMS_4S1P.m`: simulation and export helper.
- `matlab/BMS_4S1P_Calculations.m`: commented engineering arithmetic and assertion checks.
- `documentation/BMS_4S1P_Technical_Report.pdf` and `.md`: report and editable source.
- `results/BMS_4S1P_simulation.mat`: actual 600 s MATLAB SimulationOutput named `simOut`.
- `results/*_log.csv`: actual exported timeseries. First column is time in seconds. Subsequent columns are signal values; SwitchCommand has four columns in controller cell order. Voltage is V, current is A, SOC is a fraction, SOH is percent, and flag/commands are 0 or 1. These baseline CSVs have no header; newly generated helper CSVs have headers.
- `results/MATLAB_validation.txt`: sanitized execution record and signal endpoint summary.
- `results/calculations`: analytical example outputs, separate from actual simulation results.
- `FILE_MANIFEST_SHA256.csv`: file sizes and integrity hashes for the package, excluding the manifest itself.

## Verified result

The copied model completed 600 s in MATLAB R2026a Update 5. Voltage changed from 15.265024 to 15.103232 V; current from 0.76325122 to 0.75516161 A; scalar SOC from 0.825 to 0.78324887. FaultFlag remained 0. Final balancing commands were [1 1 0 1]. SOH remained 100 percent because available capacity is fixed at 3.03 Ah.

The calculation function executed successfully and checked capacity, coulomb integration, strict fault thresholds, and SOH arithmetic. This does not replace physical model fault injection or balancing convergence tests.

## Interpret the saved model correctly

The physical cell SOC targets are [0.90;0.80;0.50;0.80], while the scalar estimator starts at 0.825. The scalar estimate is not initialized to the physical mean or minimum and does not count individual shunt currents. SOH is a fixed capacity ratio, not an aging estimator. Protection raises a pack-level flag but does not disconnect the load; individual cell protection is not implemented. Balancing is implemented, but a 600 s run does not demonstrate full equalization of the large initial mismatch.

The source model has been preserved, not silently changed to correct these limitations. See the report for follow-up experiments. The October guide's 0.800 to approximately 0.755 result belongs to an earlier configuration.
