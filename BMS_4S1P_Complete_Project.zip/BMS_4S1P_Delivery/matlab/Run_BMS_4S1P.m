function simOut = Run_BMS_4S1P(stopTime)
%RUN_BMS_4S1P Run the saved model and export available timeseries logs.
% simOut = Run_BMS_4S1P(600)
% Keeps the original SLX unchanged; requires its Simulink/Simscape products.
if nargin<1, stopTime=600; end
validateattributes(stopTime,{'numeric'},{'scalar','positive','finite'});
model=Open_BMS_4S1P;
here=fileparts(mfilename('fullpath'));
outDir=fullfile(fileparts(here),'results',char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')));
mkdir(outDir);
simOut=sim(model,'StopTime',num2str(stopTime),'ReturnWorkspaceOutputs','on');
save(fullfile(outDir,'BMS_4S1P_simulation.mat'),'simOut','-v7.3');
names=simOut.who;
for k=1:numel(names)
    value=simOut.get(names{k});
    if isa(value,'timeseries')
        data=reshape(value.Data,numel(value.Time),[]);
        labels=[{'Time_s'},arrayfun(@(n)sprintf('Signal_%d',n), ...
            1:size(data,2),'UniformOutput',false)];
        writetable(array2table([value.Time,data],'VariableNames',labels), ...
            fullfile(outDir,[names{k} '.csv']));
    end
end
fprintf('Simulation saved to %s\n',outDir);
end
