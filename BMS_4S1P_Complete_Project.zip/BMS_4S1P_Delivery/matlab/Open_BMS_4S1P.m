function model = Open_BMS_4S1P
%OPEN_BMS_4S1P Open the packaged original model with its dependencies.
% Extract the entire package first. No permanent MATLAB path change.
here=fileparts(mfilename('fullpath'));
modelDir=fullfile(here,'original_model');
model='BMS_4S1P';
target=fullfile(modelDir,[model '.slx']);
if bdIsLoaded(model)
    loadedFile=get_param(model,'FileName');
    if ~strcmpi(loadedFile,target)
        error('BMS:DifferentCopyOpen', ...
            'Another BMS_4S1P copy is open. Save and close it before opening this package.');
    end
end
addpath(modelDir);
open_system(target);
fprintf('Opened packaged model: %s\n',target);
end
